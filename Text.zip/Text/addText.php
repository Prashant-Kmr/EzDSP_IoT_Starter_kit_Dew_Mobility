<?php 
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//Getting values
		$textValue = $_POST['textValue'];
		
		//Creating an sql query
		$sql = "INSERT INTO text (textValue) VALUES ('$textValue')";
		
		//Importing our db connection script
		require_once('dbHConnect.php');
		
		//Executing query to database
		if(mysqli_query($con,$sql)){
			echo 'Text Added Successfully';
		}
		else{
			echo 'Could Not Add Text';
		}
		
		//Closing the database 
		mysqli_close($con);
	}

?>