package com.example.user1.helloworld;

/**
 * Created by user1 on 02/05/2016.
 */
public class Config {

    //Address of our scripts of the CRUD
    public static final String URL_ADD="http://192.168.43.226/Text/addText.php";


    //Keys that will be used to send the request to php scripts
    public static final String KEY_TEXT_TEXTID = "textId";
    public static final String KEY_TEXT_TEXT = "textValue";


    //JSON Tags
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_TEXTID = "textId";
    public static final String TAG_TEXT = "text";

    //employee id to pass with intent
    public static final String TEXT_ID = "text_id";
}

