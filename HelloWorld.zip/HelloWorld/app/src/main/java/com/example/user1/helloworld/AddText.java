package com.example.user1.helloworld;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class AddText extends AppCompatActivity implements View.OnClickListener {

    //Defining views
    private EditText editTextValue;

    private Button buttonAdd;
    private Button buttonClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_text);

        //Initializing views
        editTextValue = (EditText) findViewById(R.id.editTextValue);


        buttonAdd = (Button) findViewById(R.id.buttonAdd);
        buttonClear = (Button) findViewById(R.id.buttonClear);

        //Setting listeners to button
        buttonAdd.setOnClickListener(this);
        buttonClear.setOnClickListener(this);
    }


    //Adding an employee
    private void addText(){

        final String textValue = editTextValue.getText().toString().trim();

        class AddNewText extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(AddText.this,"Adding...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(AddText.this, s, Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put(Config.KEY_TEXT_TEXT,textValue);

                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(Config.URL_ADD, params);
                return res;
            }
        }

        AddNewText ae = new AddNewText();
        ae.execute();
    }

    @Override
    public void onClick(View v) {
        if(v == buttonAdd){
            addText();
        }

        if(v == buttonClear){
            editTextValue.setText("");
        }
    }
}
